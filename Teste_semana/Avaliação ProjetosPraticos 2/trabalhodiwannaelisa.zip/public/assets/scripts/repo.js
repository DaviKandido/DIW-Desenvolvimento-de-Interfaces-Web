document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const repoNome = params.get('repo');
    const githubUsername = 'AnnaaElisa';
    const accessToken = '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'; 

    if (repoNome) {
        pegarRepositorio(githubUsername, repoNome, accessToken);
    }

    function pegarRepositorio(username, repoNome, accessToken) {
        axios.get(`https://api.github.com/repos/${username}/${repoNome}`, {
            headers: {
                Authorization: `token ${accessToken}`
            }
        })
        .then(response => {
            const repo = response.data;
            document.getElementById('repo-title').textContent = repo.name;
            document.getElementById('repo-description').textContent = repo.description || 'Sem descrição';
            document.getElementById('repo-created').textContent = new Date(repo.created_at).toLocaleDateString();
            document.getElementById('repo-language').textContent = repo.language || 'Não especificada';
            document.getElementById('repo-topics').textContent = repo.topics.join(', ') || 'Nenhum tópico';
            document.getElementById('repo-stars').textContent = repo.stargazers_count;
            document.getElementById('repo-forks').textContent = repo.forks_count;
            document.getElementById('repo-url').href = repo.html_url;
        })
        .catch(error => console.error('Erro ao buscar detalhes do repositório:', error));
    }
});
