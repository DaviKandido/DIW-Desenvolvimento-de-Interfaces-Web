const githubUsername = 'AnnaaElisa';
const accessToken = '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';
const jsonServerUrl = 'https://30fde28b-214c-4818-92d8-9fd4ed4aa4ac-00-1nxk0qldg32fh.spock.replit.dev/';

function pegarPerfilGithub() {
  axios.get(`https://api.github.com/users/${githubUsername}`, {
    headers: {
      Authorization: `token ${accessToken}`
    }
  })
  .then(response => {
    const data = response.data;
    document.getElementById('profile-pic').src = data.avatar_url;
    document.getElementById('profile-name').textContent = data.name;
    document.getElementById('profile-bio').textContent = data.bio;
    document.getElementById('profile-location').textContent = `Localização: ${data.location}`;
  })
  .catch(error => console.error('Erro ao buscar dados do perfil:', error));
}

function pegarRepoGithub() {
  axios.get(`https://api.github.com/users/${githubUsername}/repos`, {
    headers: {
      Authorization: `token ${accessToken}`
    }
  })
  .then(response => {
    const repos = response.data;
    const reposList = document.getElementById('repos-list');
    reposList.innerHTML = '';

    repos.slice(0, 3).forEach(repo => {
      const repoCard = `
        <div class="card" style="max-width: 20rem; padding-left: 20px;">
          <a class="card-body" href="repo.html?repo=${repo.name}" style="text-decoration: none;" target="_blank">
            <div class="card-body" style="background-color: white; border: 2px solid grey; height: 150px;">
              <h5 class="card-title">${repo.name}</h5>
              <p class="card-text" style="background-color: white;">${repo.description || 'Sem descrição'}</p>
              <div class="repo-stats">
                <span class="stars">${repo.stargazers_count}</span>
                <span class="forks">Forks: ${repo.forks_count}</span>
              </div>
            </div>
          </a>
        </div>
      `;
      reposList.innerHTML += repoCard;
    });
  })
  .catch(error => console.error('Erro ao buscar repositórios:', error));
}

function pegarConteudosSugeridos() {
  axios.get(`${jsonServerUrl}/suggestedContent`)
    .then(response => {
      const contents = response.data;
      const carouselInner = document.querySelector('#content-carousel .carousel-inner');
      carouselInner.innerHTML = '';

      contents.forEach((content, index) => {
        const isActive = index === 0 ? 'active' : '';
        const carouselItem = `
          <div class="carousel-item ${isActive}">
            <img src="${content.image}" class="d-block w-100" alt="${content.title}">
            <div class="carousel-caption d-none d-md-block">
              <h5>${content.title}</h5>
              <a href="${content.link}" class="btn btn-primary" target="_blank">Ver mais</a>
            </div>
          </div>
        `;
        carouselInner.innerHTML += carouselItem;
      });
    })
    .catch(error => console.error('Erro ao buscar conteúdos sugeridos:', error));
}

function pegarColegas() {
  axios.get(`${jsonServerUrl}/colleagues`)
    .then(response => {
      const colleagues = response.data;
      const colleaguesList = document.getElementById('colleagues-list');
      colleaguesList.innerHTML = '';

      colleagues.forEach(colleague => {
        const colleagueCard = `
          <div class="col-sm-4 mb-3">
            <div class="card">
              <img src="${colleague.photo}" class="card-img-top" alt="${colleague.name}">
              <div class="card-body">
                <h5 class="card-title">${colleague.name}</h5>
                <a href="${colleague.github}" class="btn btn-primary" target="_blank">Ver GitHub</a>
              </div>
            </div>
          </div>
        `;
        colleaguesList.innerHTML += colleagueCard;
      });
    })
    .catch(error => console.error('Erro ao buscar colegas:', error));
}

document.addEventListener('DOMContentLoaded', function() {
  pegarPerfilGithub();
  pegarRepoGithub();
  pegarConteudosSugeridos();
  pegarColegas();
});
